# Spreadsheet Compiler CaaS (Monolith)

Spring Boot monolithic application that implements front-end compiler phases (lexer + parser + AST + structured syntax errors) with JWT auth, submission persistence, history endpoints, and a simple browser UI.

## Run

```bash
mvn spring-boot:run
```

Open [http://localhost:8080](http://localhost:8080).

## Modules

- `auth`: registration/login, JWT filter, security config
- `compiler`: lexer/parser/AST and parse endpoint
- `submission`: stores parse snapshots
- `history`: paginated history list + detail access
- `common`: shared exception handling

## Key APIs

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/compiler/parse` (authenticated)
- `POST /api/submissions` (authenticated)
- `GET /api/history` (authenticated)
- `GET /api/history/{submissionId}` (authenticated)

## Test

```bash
mvn test
```
