package edu.university.spreadsheetcompiler.compiler;

import edu.university.spreadsheetcompiler.compiler.ast.FunctionCallNode;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ParserTest {

    private final CompilerService compilerService = new CompilerService();

    @Test
    void parsesNestedFunctionsAndRange() {
        var result = compilerService.parse("=IF(SUM(A1:A5) >= 10, MAX(B1, 3), MIN(C1, 1))",
                CompilerModels.ParseOptions.defaults());

        assertTrue(result.errors().isEmpty());
        assertInstanceOf(FunctionCallNode.class, result.ast());
    }

    @Test
    void reportsMissingCommaInFunctionArguments() {
        var result = compilerService.parse("=IF(A1 > 10 B1, 0)", CompilerModels.ParseOptions.defaults());
        assertFalse(result.errors().isEmpty());
        assertTrue(result.errors().stream().anyMatch(e -> e.code().equals("PARSER_MISSING_COMMA")));
    }

    @Test
    void reportsInvalidExpression() {
        var result = compilerService.parse("=A1 + )", CompilerModels.ParseOptions.defaults());
        assertFalse(result.errors().isEmpty());
        assertTrue(result.errors().stream().anyMatch(e -> e.code().startsWith("PARSER_")));
    }

    @Test
    void validatesFunctionArity() {
        var badIf = compilerService.parse("=IF(A1, B1)", CompilerModels.ParseOptions.defaults());
        var badSum = compilerService.parse("=SUM()", CompilerModels.ParseOptions.defaults());

        assertTrue(badIf.errors().stream().anyMatch(e -> e.code().equals("PARSER_FUNCTION_ARITY")));
        assertTrue(badSum.errors().stream().anyMatch(e -> e.code().equals("PARSER_FUNCTION_ARITY")));
    }
}

