package edu.university.spreadsheetcompiler.compiler;

import edu.university.spreadsheetcompiler.compiler.ast.AstRenderer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class AstRendererTest {

    private final CompilerService compilerService = new CompilerService();

    @Test
    void rendersExampleFormulaAsTreeAndJson() {
        var result = compilerService.parse("=SUM(A1, MAX(B1:B5), 10)", CompilerModels.ParseOptions.defaults());

        String tree = AstRenderer.toTree(result.ast());
        String json = AstRenderer.toPrettyJson(result.ast());

        assertTrue(tree.contains("FunctionCallNode(SUM)"));
        assertTrue(tree.contains("FunctionCallNode(MAX)"));
        assertTrue(tree.contains("RangeNode"));
        assertTrue(json.contains("\"type\" : \"FunctionCallNode\""));
        assertTrue(json.contains("\"name\" : \"SUM\""));
    }
}

