package edu.university.spreadsheetcompiler.compiler;

import edu.university.spreadsheetcompiler.compiler.CompilerModels.ParseOptions;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CompilerServiceTest {
    private final CompilerService service = new CompilerService();

    @Test
    void parsesValidFormula() {
        var result = service.parse("=SUM(A1, B2, 5)", ParseOptions.defaults());
        assertTrue(result.errors().isEmpty());
        assertNotNull(result.ast());
        assertFalse(result.tokens().isEmpty());
    }

    @Test
    void reportsInvalidIfArity() {
        var result = service.parse("=IF(A1 > 10, B1)", ParseOptions.defaults());
        assertFalse(result.errors().isEmpty());
    }
}
