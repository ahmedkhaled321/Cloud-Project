package edu.university.spreadsheetcompiler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ApiFlowTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;

    @Test
    void authParseAndHistoryFlow() throws Exception {
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"student1\",\"email\":\"s1@uni.edu\",\"password\":\"StrongPass123\"}"))
                .andExpect(status().isOk());

        String login = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"usernameOrEmail\":\"student1\",\"password\":\"StrongPass123\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        JsonNode tokenNode = mapper.readTree(login);
        String token = tokenNode.get("accessToken").asText();

        mvc.perform(post("/api/compiler/parse").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"formula\":\"=A1 + B2\",\"options\":{\"includeTokens\":true,\"includeAstJson\":true,\"includeAstTree\":true,\"validateFunctions\":true}}"))
                .andExpect(status().isOk());

        mvc.perform(post("/api/submissions").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"formula\":\"=A1 + B2\",\"parseOptions\":{\"includeTokens\":true,\"includeAstJson\":true,\"includeAstTree\":true,\"validateFunctions\":true}}"))
                .andExpect(status().isOk());

        mvc.perform(get("/api/history?page=0&size=10").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
    }

    @Test
    void parseSubmitHistoryRequireAuth() throws Exception {
        mvc.perform(post("/parse")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"formula\":\"=SUM(A1, B2)\"}"))
                .andExpect(status().isForbidden());
        mvc.perform(post("/submit")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"formula\":\"=SUM(A1, B2)\"}"))
                .andExpect(status().isForbidden());
        mvc.perform(get("/history"))
                .andExpect(status().isForbidden());
    }

    @Test
    void authenticatedParseSubmitHistoryWork() throws Exception {
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"student2\",\"email\":\"s2@uni.edu\",\"password\":\"StrongPass123\"}"))
                .andExpect(status().isOk());

        String login = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"usernameOrEmail\":\"student2\",\"password\":\"StrongPass123\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String token = mapper.readTree(login).get("accessToken").asText();

        mvc.perform(post("/parse").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"formula\":\"=SUM(A1, B2)\"}"))
                .andExpect(status().isOk());
        mvc.perform(post("/submit").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"formula\":\"=SUM(A1, B2)\"}"))
                .andExpect(status().isOk());
        mvc.perform(get("/history").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
    }
}
