package edu.university.spreadsheetcompiler.compiler;

import java.util.List;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LexerTest {

    @Test
    void lexesFunctionWithRangeAndComparison() {
        var result = new Lexer("=IF(SUM(A1:A5) >= 10, MAX(B1, 3), MIN(C1, 1))").lex();

        List<TokenType> types = result.tokens().stream().map(t -> t.type()).toList();
        assertTrue(result.errors().isEmpty());
        assertEquals(
                List.of(
                        TokenType.EQUALS, TokenType.FUNCTION, TokenType.LPAREN, TokenType.FUNCTION, TokenType.LPAREN,
                        TokenType.CELL_REF, TokenType.COLON, TokenType.CELL_REF, TokenType.RPAREN, TokenType.GTE,
                        TokenType.NUMBER, TokenType.COMMA, TokenType.FUNCTION, TokenType.LPAREN, TokenType.CELL_REF,
                        TokenType.COMMA, TokenType.NUMBER, TokenType.RPAREN, TokenType.COMMA, TokenType.FUNCTION,
                        TokenType.LPAREN, TokenType.CELL_REF, TokenType.COMMA, TokenType.NUMBER, TokenType.RPAREN,
                        TokenType.RPAREN, TokenType.EOF
                ),
                types
        );
    }

    @Test
    void lexesArithmeticCellReferences() {
        var result = new Lexer("=AA10+B2/3").lex();
        List<TokenType> types = result.tokens().stream().map(t -> t.type()).toList();
        assertTrue(result.errors().isEmpty());
        assertEquals(
                List.of(TokenType.EQUALS, TokenType.CELL_REF, TokenType.PLUS, TokenType.CELL_REF, TokenType.SLASH, TokenType.NUMBER, TokenType.EOF),
                types
        );
    }

    @Test
    void reportsInvalidCharacter() {
        var result = new Lexer("=A1 $ B2").lex();
        assertFalse(result.errors().isEmpty());
        assertEquals("LEXER_INVALID_TOKEN", result.errors().get(0).code());
    }

    @Test
    void reportsInvalidCellReference() {
        var result = new Lexer("=A0+1").lex();
        assertFalse(result.errors().isEmpty());
        assertEquals("LEXER_INVALID_CELL_REFERENCE", result.errors().get(0).code());
    }

    @Test
    void reportsUnsupportedIdentifier() {
        var result = new Lexer("=AVG(A1,A2)").lex();
        assertFalse(result.errors().isEmpty());
        assertEquals("LEXER_UNSUPPORTED_IDENTIFIER", result.errors().get(0).code());
    }

    @Test
    void reportsMissingLeadingEquals() {
        var result = new Lexer("SUM(A1:A5)").lex();
        assertFalse(result.errors().isEmpty());
        assertTrue(result.errors().stream().anyMatch(e -> e.code().equals("LEXER_MISSING_EQUALS_PREFIX")));
    }
}
